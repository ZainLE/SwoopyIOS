import SwiftUI
import Supabase
import AuthenticationServices
import UIKit

private enum AuthProvider {
    case apple, google
}

struct AuthView: View {
    @EnvironmentObject var svc: SupabaseService

    @State private var loading: AuthProvider? = nil
    @State private var errorMessage: String?

    private var hasGoogleLogo: Bool {
        UIImage(named: "googlelogo") != nil
    }

    var body: some View {
        VStack(spacing: 28) {
            Spacer()

            header

            if let errorMessage {
                errorView(errorMessage)
            }

            appleButton
                .disabled(loading != nil)
                .padding(.horizontal)

            googleButton
                .disabled(loading != nil)
                .padding(.horizontal)

            Spacer()
        }
    }

    // MARK: - Subviews

    private var header: some View {
        Text("Swoopy")
            .font(.system(size: 48, weight: .heavy, design: .rounded))
            .foregroundStyle(.primary)
    }

    private func errorView(_ message: String) -> some View {
        Text(message)
            .font(.footnote)
            .foregroundStyle(.red)
            .multilineTextAlignment(.center)
            .padding(.horizontal)
    }

    private var appleButton: some View {
        Button(action: signInWithApple) {
            HStack(spacing: 12) {
                Image(systemName: "apple.logo")
                    .imageScale(.large)
                if loading == .apple {
                    ProgressView().tint(.white)
                    Text("Signing in…")
                        .fontWeight(.semibold)
                } else {
                    Text("Continue with Apple")
                        .fontWeight(.semibold)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .foregroundColor(.white)
            .background(.black)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }

    private var googleButton: some View {
        Button(action: signInWithGoogle) {
            HStack(spacing: 12) {
                googleIcon
                if loading == .google {
                    ProgressView()
                    Text("Signing in…")
                        .fontWeight(.semibold)
                } else {
                    Text("Continue with Google")
                        .fontWeight(.semibold)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(.systemBackground))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }

    @ViewBuilder
    private var googleIcon: some View {
        if hasGoogleLogo {
            Image("googlelogo")
                .resizable()
                .frame(width: 20, height: 20)
        } else {
            Image(systemName: "globe")
        }
    }

    // MARK: - Actions

    private func signInWithApple() {
        guard loading == nil else { return }
        loading = .apple
        errorMessage = nil
        Task {
            defer { loading = nil }
            do {
                let window = UIApplication.shared.connectedScenes
                    .compactMap { $0 as? UIWindowScene }
                    .first?.keyWindow
                try await svc.signInWithApple(on: window)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func signInWithGoogle() {
        guard loading == nil else { return }
        loading = .google
        errorMessage = nil
        Task {
            defer { loading = nil }
            do {
                let redirect = URL(string: "swoopy://auth/callback")!
                try await SupabaseService.shared.client.auth
                    .signInWithOAuth(provider: .google, redirectTo: redirect)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
