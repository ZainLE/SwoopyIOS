//
//  GlassTabBar.swift
//  TrashPicker
//
//  Created by Zain Latif  on 19/9/25.
//

import SwiftUI

// MARK: - Public API

enum MainTab: Hashable {
    case feed, reservations, profile
}

struct GlassTabBar: View {
    @Binding var selection: MainTab
    var addTapped: () -> Void

    var body: some View {
        HStack(spacing: 14) {
            // Main glass pill with 3 segments
            HStack(spacing: 8) {
                Segment(
                    title: "Feed",
                    imageAsset: "Feedicon",
                    sfSymbol: "rectangle.stack",
                    isSelected: selection == .feed
                ) { selection = .feed }

                Segment(
                    title: "Reservations",
                    imageAsset: "Reserveicon",
                    sfSymbol: "square.grid.2x2",
                    isSelected: selection == .reservations
                ) { selection = .reservations }

                Segment(
                    title: "Profile",
                    imageAsset: "Profileicon",
                    sfSymbol: "person",
                    isSelected: selection == .profile
                ) { selection = .profile }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(.ultraThinMaterial, in: Capsule())
            .overlay {
                Capsule().stroke(.white.opacity(0.20), lineWidth: 1)
                    .shadow(color: .black.opacity(0.06), radius: 12, y: 6)
            }

            // Floating round "Add"
            Button(action: addTapped) {
                HStack(spacing: 0) {
                    AssetOrSymbol(name: "Addicon", fallback: "plus")
                        .font(.system(size: 18, weight: .semibold))
                }
                .frame(width: 56, height: 56)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().stroke(.white.opacity(0.25), lineWidth: 1))
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 10)
        .padding(.bottom, max(10, safeAreaBottomInset()))
    }
}

// MARK: - Segment Button

private struct Segment: View {
    let title: String
    let imageAsset: String
    let sfSymbol: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                AssetOrSymbol(name: imageAsset, fallback: sfSymbol)
                    .font(.system(size: 18, weight: .semibold))
                Text(title)
                    .font(.subheadline.weight(.semibold))
            }
            .foregroundStyle(isSelected ? Color.appGreen : Color.primary.opacity(0.85))
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                Capsule()
                    .fill(isSelected ? Color.white.opacity(0.75) : .clear)
                    .overlay(
                        Capsule()
                            .stroke(isSelected ? Color.appGreen.opacity(0.35) : .clear, lineWidth: 1)
                    )
                    .shadow(color: isSelected ? Color.appGreen.opacity(0.16) : .clear, radius: 10, y: 4)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Utilities

private struct AssetOrSymbol: View {
    let name: String
    let fallback: String
    var body: some View {
        if UIImage(named: name) != nil {
            Image(name).resizable().scaledToFit().frame(width: 20, height: 20)
        } else {
            Image(systemName: fallback)
        }
    }
}

private func safeAreaBottomInset() -> CGFloat {
    UIApplication.shared.connectedScenes
        .compactMap { $0 as? UIWindowScene }
        .first?.windows.first?.safeAreaInsets.bottom ?? 0
}

private extension Color {
    /// #00513F
    static let appGreen = Color(red: 0x00/255, green: 0x51/255, blue: 0x3F/255)
}
