import SwiftUI

struct RootView: View {
    @State private var tab: MainTab = .feed
    @State private var showAdd = false

    var body: some View {
        ZStack {
            // Main content for each tab
            Group {
                switch tab {
                case .feed:
                    NavigationStack { SwipeDeckView() }
                case .reservations:
                    NavigationStack { ReservationsView() }
                case .profile:
                    NavigationStack { ProfileView() }
                }
            }
            .ignoresSafeArea(.keyboard)

            // Glass bar overlay
            VStack {
                Spacer()
                GlassTabBar(selection: $tab) {
                    // "Add" tapped — present add sheet
                    showAdd = true
                }
            }
        }
        .sheet(isPresented: $showAdd) {
            NavigationStack { AddTrashView() }
                .presentationDetents([.large])
        }
        .tint(AppColor.darkGreen)
    }
}
