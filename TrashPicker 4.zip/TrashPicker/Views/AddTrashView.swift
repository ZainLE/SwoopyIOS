import SwiftUI
import MapKit
import PhotosUI
import CoreLocation

struct AddTrashView: View {
    @EnvironmentObject var svc: SupabaseService
    @EnvironmentObject var loc: LocationManager
 

    // ...
    position = .userLocation(fallback: fallbackRegion, loc: loc)

    // Photos
    @State private var selections: [PhotosPickerItem] = []
    @State private var images: [UIImage] = []

    // Required (minimal): condition + mode
    @State private var condition: String = "good"  // "bad" | "good" | "excellent" -> map to your backend values
    @State private var mode: String = "street"     // "street" | "home"

    // Optional description behind a circle toggle
    @State private var wantDescription = false
    @State private var descriptionText = ""

    // Map camera
    @State private var position: MapCameraPosition = .userLocation(fallback: .init(center: .init(latitude: 41.3874, longitude: 2.1686),
                                                                                   span: .init(latitudeDelta: 0.02, longitudeDelta: 0.02))))
    // Selected coordinate (defaults to user when available)
    @State private var selectedCoord: CLLocationCoordinate2D?

    @State private var isSaving = false
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {

                // Photos (max 3)
                PhotosPicker(selection: $selections,
                             maxSelectionCount: 3,
                             matching: .images) {
                    HStack {
                        Text("Add up to 3 photos")
                        Spacer()
                        Image(systemName: "camera.fill")
                    }
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                }
                .onChange(of: selections) { _ in loadPhotos() }

                if !images.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(Array(images.enumerated()), id: \.offset) { _, img in
                                Image(uiImage: img)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 160, height: 120)
                                    .clipped()
                                    .cornerRadius(12)
                            }
                        }.padding(.horizontal, 2)
                    }
                }

                // Condition (simple segmented)
                Picker("Condition", selection: $condition) {
                    Text("Bad").tag("bad")
                    Text("Good").tag("good")
                    Text("Excellent").tag("excellent")
                }
                .pickerStyle(.segmented)

                // Mode
                Picker("Location", selection: $mode) {
                    Text("Street").tag("street")
                    Text("Home").tag("home")
                }
                .pickerStyle(.segmented)

                // Map
                mapSection

                // Optional description behind a circle button
                Button {
                    withAnimation { wantDescription.toggle() }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: wantDescription ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(wantDescription ? AppColor.darkGreen : .secondary)
                        Text("Add a description (optional)")
                            .foregroundStyle(.primary)
                        Spacer()
                    }
                }

                if wantDescription {
                    VStack(alignment: .leading, spacing: 6) {
                        TextEditor(text: $descriptionText)
                            .frame(minHeight: 100)
                            .padding(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
                            )
                        Text("\(descriptionText.count)/100")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }

                if let error { Text(error).foregroundStyle(.red).font(.footnote) }

                // Post
                Button(action: save) {
                    HStack {
                        if isSaving { ProgressView() }
                        Text(isSaving ? "Posting..." : "Post")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(AppColor.darkGreen)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .disabled(isSaving || images.isEmpty || currentCoordinate == nil)
            }
            .padding()
        }
        .task {
            // Ensure we have a coordinate early
            if loc.userLocation == nil { loc.request() }
            if selectedCoord == nil, let c = loc.userLocation?.coordinate { selectedCoord = c }
        }
        .navigationTitle("New Post")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Map

    @ViewBuilder
    private var mapSection: some View {
        Map(position: $position, interactionModes: .all, showsUserLocation: true) {
            if let c = currentCoordinate {
                if mode == "home" {
                    MapCircle(center: c, radius: 500)
                        .foregroundStyle(AppColor.darkGreen.opacity(0.20))
                } else {
                    Annotation("Here", coordinate: c) {
                        Image(systemName: "mappin.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.red)
                            .shadow(radius: 1)
                    }
                }
            }
        }
        .frame(height: 240)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(alignment: .bottomTrailing) {
            // Snap to user location
            Button {
                if let c = loc.userLocation?.coordinate {
                    selectedCoord = c
                    position = .region(.init(center: c, span: .init(latitudeDelta: 0.01, longitudeDelta: 0.01)))
                }
            } label: {
                Image(systemName: "location.circle.fill").font(.title2)
                    .padding(10)
                    .background(.ultraThinMaterial, in: Circle())
            }
            .padding(10)
        }
    }

    // Exact vs Approx center: we always keep a single “selectedCoord”
    private var currentCoordinate: CLLocationCoordinate2D? {
        if let c = selectedCoord { return mode == "home" ? approximate(c) : c }
        if let c = loc.userLocation?.coordinate { return mode == "home" ? approximate(c) : c }
        return nil
    }

    private func approximate(_ c: CLLocationCoordinate2D, grid: Double = 0.01) -> CLLocationCoordinate2D {
        let lat = (c.latitude / grid).rounded() * grid
        let lon = (c.longitude / grid).rounded() * grid
        return .init(latitude: lat, longitude: lon)
    }

    // MARK: - Photos

    private func loadPhotos() {
        images = []
        Task {
            for item in selections.prefix(3) {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let img = UIImage(data: data) {
                    images.append(img)
                }
            }
        }
    }

    // MARK: - Save

    private func save() {
        guard let coord = loc.userLocation?.coordinate ?? selectedCoord else {
            error = "Location not available yet."
            return
        }
        error = nil
        isSaving = true

        Task {
            defer { isSaving = false }
            do {
                // No title/category in UI → provide safe defaults for backend
                let defaultTitle = "Free item"
                let defaultCategory = "misc"

                try await svc.createItem(
                    images: images,
                    title: defaultTitle,
                    description: descriptionText.isEmpty ? nil : String(descriptionText.prefix(100)),
                    category: defaultCategory,
                    condition: condition,
                    mode: mode,                // "street" or "home"
                    coordinate: coord
                )

                // Refresh lists
                if let c = loc.userLocation?.coordinate {
                    await svc.fetchFeed(near: c)
                }
                await svc.fetchMyStuff()
            } catch {
                self.error = error.localizedDescription
                return
            }
        }
    }
}

// Small convenience for a default user-centered region
private extension MapCameraPosition {
    static func userLocation(fallback: MKCoordinateRegion, loc: LocationManager?) -> MapCameraPosition {
        if let c = loc?.userLocation?.coordinate {
            return .region(.init(center: c, span: .init(latitudeDelta: 0.02, longitudeDelta: 0.02)))
        }
        return .region(fallback)
    }
}
