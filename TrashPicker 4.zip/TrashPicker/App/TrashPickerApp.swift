import SwiftUI
import CoreLocation
import UIKit

@main
struct TrashPickerApp: App {
    init() {
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.label]
    }
    @StateObject private var svc = SupabaseService.shared
    @StateObject private var loc = LocationManager()
    @StateObject private var ck = CKTrashService()

    /// Use a neutral fallback for first load if we don’t have a GPS fix yet
    private let fallbackCenter = CLLocationCoordinate2D(latitude: 41.387, longitude: 2.170)

    var body: some Scene {
        WindowGroup {
            Group {
                if svc.isAuthenticated {
                    RootView()
                } else {
                    AuthView()
                }
            }
                .environmentObject(svc)
                .environmentObject(loc)
                .environmentObject(ck)
                .task {
                    await svc.ensureSession()   // no anonymous sign-in; will leave AuthView if not signed in
                    if svc.isAuthenticated {
                        if loc.authorization == .notDetermined { loc.request() }
                        let center = loc.userLocation?.coordinate ?? fallbackCenter
                        await svc.fetchFeed(near: center)
                        await svc.fetchMyStuff()
                    }
                }
                // refresh feed once we get a better coordinate later
                .onChange(of: loc.userLocation) { newLoc in
                    guard let c = newLoc?.coordinate else { return }
                    Task { await svc.fetchFeed(near: c) }
                }
                // Handle OAuth redirect deep link
                .onOpenURL { url in
                    Task {
                        _ = try? await SupabaseService.shared.client.auth.session(from: url)
                        await svc.refreshAuthState()
                    }
                }
        }
    }
}
