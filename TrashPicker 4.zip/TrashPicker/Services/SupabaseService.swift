import Foundation
import SwiftUI
import CoreLocation
import UIKit
import Supabase
import AuthenticationServices
import CryptoKit

// MARK: - SupabaseService (Option A: no auth listener, no anonymous sessions)

/// Central Supabase facade used across the app.
/// - App is *gated*: there is **no** anonymous session fallback.
/// - We restore a previous session on launch (Keychain).
/// - After OAuth returns via deep link, call `await refreshAuthState()` to flip UI.
@MainActor
final class SupabaseService: NSObject, ObservableObject {
    static let shared = SupabaseService()

    // Published state
    @Published var feed: [TrashDTO] = []
    @Published var myUploads: [TrashDTO] = []
    @Published var myReservations: [TrashDTO] = []
    @Published var pending: [TrashDTO] = []

    // Auth state
    @Published private(set) var userId: UUID?
    @Published private(set) var session: Session?
    /// TRUE only for real OAuth users (Google/Apple/Email).
    @Published var isAuthenticated: Bool = false

    // Supabase client (URL + anon key must be provided by SupabaseConfig)
    let client = SupabaseClient(
        supabaseURL: SupabaseConfig.url,
        supabaseKey: SupabaseConfig.anonKey
    )

    private override init() {
        super.init()
        // Restore a previous session on launch (no await in init; use a Task)
        Task { [weak self] in
            await self?.restoreSessionIfPossible()
        }
        // NOTE: No auth listener, no dev bypass, no anonymous sign-in here.
    }

    // MARK: - Public Auth API

    /// Call on app start. Does **not** create anonymous sessions.
    /// If a valid session exists (from Keychain or SDK), we publish it.
    func ensureSession() async {
        do {
            // Try to read current SDK session (if already set)
            let s = try? await client.auth.session
            applyAuthSession(s)
        } catch {
            applyAuthSession(nil)
        }
    }

    /// Exposed so callers can force a re-read of the current session (used after deep-link return).
    func refreshAuthState() async {
        let s = try? await client.auth.session
        applyAuthSession(s)
    }

    /// Google OAuth (PKCE). Ensure `swoopy://auth/callback` is added in Supabase Redirect URLs.
    func signInWithGoogle() async throws {
        let redirect = URL(string: "swoopy://auth/callback")!
        _ = try await client.auth.signInWithOAuth(
            provider: .google,
            redirectTo: redirect,
            scopes: "email profile"
        )
        // After the browser returns to your app, .onOpenURL should run and then call refreshAuthState().
    }

    /// Sign in with Apple (secure nonce flow).
    func signInWithApple(on window: UIWindow?) async throws {
        let nonce = Self.randomNonceString()
        let hashed = Self.sha256(nonce)
        let request = ASAuthorizationAppleIDProvider().createRequest()
        request.requestedScopes = [.fullName, .email]
        request.nonce = hashed

        let credential = try await Self.performAppleSignIn(request: request, on: window)
        guard let tokenData = credential.identityToken,
              let idToken = String(data: tokenData, encoding: .utf8) else {
            throw SimpleError(message: "Failed to read Apple identity token")
        }

        _ = try await client.auth.signInWithIdToken(
            credentials: .init(provider: .apple, idToken: idToken, nonce: nonce)
        )
        // After deep link (if any), call refreshAuthState().
    }

    /// Email OTP magic link.
    func signInWithEmailMagicLink(_ email: String) async throws {
        let redirect = URL(string: "swoopy://auth/callback")!
        try await client.auth.signInWithOTP(email: email, redirectTo: redirect)
        // After user taps the magic link and returns, call refreshAuthState().
    }

    func signOut() async {
        do { try await client.auth.signOut() }
        catch { print("signOut error:", error.localizedDescription) }
        applyAuthSession(nil)
    }

    // MARK: - Feed (via ItemsService)

    func fetchFeed(near: CLLocationCoordinate2D,
                   radiusKM: Double = 50,
                   category: String? = nil,
                   condition: String? = nil) async {
        do {
            let rows = try await ItemsService.shared.getFeed(
                lat: near.latitude,
                lon: near.longitude,
                radiusKm: radiusKM,
                category: category,
                condition: condition
            )
            self.feed = rows.map { r in
                TrashDTO(
                    id: r.id,
                    title: r.title,
                    description: r.description,
                    category: r.category,
                    condition: r.condition,
                    mode: r.mode,
                    city: nil,
                    lat: r.lat,
                    lon: r.lon,
                    approxLat: r.approx_lat,
                    approxLon: r.approx_lon,
                    photoURLs: r.photo_urls.compactMap(URL.init(string:)),
                    createdAt: r.created_at,
                    expiresAt: r.expires_at,
                    status: r.status,
                    reservedUntil: r.reserved_until,
                    reservedBy: r.reserved_by,
                    uploader: r.uploader,
                    pickedUpAt: r.picked_up_at
                )
            }
        } catch {
            print("fetchFeed:", error.localizedDescription)
        }
    }

    // MARK: - My stuff

    func fetchMyStuff() async {
        guard let uid = userId else { return }
        do {
            // uploads
            let uploads: [DBItem] = try await client
                .from(SupabaseConfig.postsTable)
                .select()
                .eq("uploader", value: uid.uuidString)
                .order("created_at", ascending: false)
                .execute().value
            self.myUploads = uploads.map { $0.toDTO() }

            // active reservations
            let nowIso = ISOTime.isoString(Date())
            let active: [DBItem] = try await client
                .from(SupabaseConfig.postsTable)
                .select()
                .eq("reserved_by", value: uid.uuidString)
                .gt("reserved_until", value: nowIso)
                .order("reserved_until", ascending: false)
                .execute().value
            self.myReservations = active.map { $0.toDTO() }

            // pending approvals for my items (optional table)
            struct Row: Decodable { let id: UUID }
            let pend: [Row] = try await client
                .from("reservations")
                .select("item_id:id, item_id")
                .eq("status", value: "pending")
                .execute().value
            let ids = pend.map { $0.id }
            if ids.isEmpty {
                self.pending = []
            } else {
                let pendItems: [DBItem] = try await client
                    .from(SupabaseConfig.postsTable)
                    .select()
                    .in("id", values: ids)
                    .eq("uploader", value: uid.uuidString)
                    .execute().value
                self.pending = pendItems.map { $0.toDTO() }
            }
        } catch {
            print("fetchMyStuff:", error.localizedDescription)
        }
    }

    // MARK: - Create post

    func createItem(images: [UIImage],
                    title: String,
                    description: String?,
                    category: String,
                    condition: String,
                    mode: String,                       // "street" | "home"
                    coordinate: CLLocationCoordinate2D,  // exact user point
                    homeGrid: Double = 0.01) async throws {
        // Must be signed in
        guard let uid = userId else { throw SimpleError(message: "No user/session") }

        let photoURLs = try await ImageStorage.uploadJPEGs(client: client, images: images, uploader: uid)
        guard !photoURLs.isEmpty else { throw SimpleError(message: "Image upload failed") }

        // For "home", obfuscate exact lat/lon on the client.
        var lat = coordinate.latitude, lon = coordinate.longitude
        var approxLat: Double? = nil, approxLon: Double? = nil
        if mode == "home" {
            approxLat = (lat / homeGrid).rounded() * homeGrid
            approxLon = (lon / homeGrid).rounded() * homeGrid
            lat = .nan; lon = .nan
        }

        struct Insert: Encodable {
            let id: UUID
            let uploader: UUID
            let title: String
            let description: String?
            let category: String
            let condition: String
            let mode: String
            let lat: Double?
            let lon: Double?
            let approx_lat: Double?
            let approx_lon: Double?
            let photo_urls: [String]
            let created_at: String
            let expires_at: String
            let status: String
        }

        let now = Date()
        let payload = Insert(
            id: UUID(),
            uploader: uid,
            title: title,
            description: description?.prefix(100).description,
            category: category,
            condition: condition,
            mode: mode,
            lat: mode == "street" ? lat : nil,
            lon: mode == "street" ? lon : nil,
            approx_lat: mode == "home" ? approxLat : nil,
            approx_lon: mode == "home" ? approxLon : nil,
            photo_urls: photoURLs,
            created_at: ISOTime.isoString(now),
            expires_at: ISOTime.isoString(now.addingTimeInterval(24*3600)),
            status: "available"
        )

        _ = try await client
            .from(SupabaseConfig.postsTable)
            .insert(payload)
            .execute()
    }

    // MARK: - Reservation life-cycle

    func reserve(_ item: TrashDTO, hours: Int = 6) async throws {
        try await ItemsService.shared.reservePost(itemId: item.id, hours: hours)
    }

    func approve(reservationId: UUID, hours: Int = 6) async throws {
        struct Params: Encodable { let p_reservation_id: UUID; let p_hours: Int }
        let params = Params(p_reservation_id: reservationId, p_hours: hours)
        _ = try await client.rpc("approve_reservation", params: params).execute()
    }

    func cancelReservation(_ item: TrashDTO) async {
        struct Params: Encodable { let p_post_id: UUID }
        do { _ = try await client.rpc("clear_reservation", params: Params(p_post_id: item.id)).execute() }
        catch { print("cancelReservation:", error.localizedDescription) }
    }

    func confirmPickup(_ item: TrashDTO) async {
        struct Params: Encodable { let p_post_id: UUID }
        do { _ = try await client.rpc("mark_picked_up", params: Params(p_post_id: item.id)).execute() }
        catch { print("confirmPickup:", error.localizedDescription) }
    }
}

// MARK: - Internal auth plumbing

private extension SupabaseService {
    /// Non-async; safe to call from any main-actor context.
    func applyAuthSession(_ session: Session?) {
        self.session = session
        if let s = session {
            self.userId = s.user.id
            self.isAuthenticated = !Self.isAnonymousUser(s.user)
            KeychainStore.saveSession(accessToken: s.accessToken, refreshToken: s.refreshToken)
        } else {
            self.userId = nil
            self.isAuthenticated = false
            KeychainStore.clearSession()
        }
    }

    /// Restore a previous session from Keychain (if any).
    func restoreSessionIfPossible() async {
        guard let creds = KeychainStore.loadSession() else {
            applyAuthSession(nil)
            return
        }
        do {
            // If tokens are still valid, this rehydrates a real session.
            let s = try await client.auth.setSession(
                accessToken: creds.accessToken,
                refreshToken: creds.refreshToken
            )
            applyAuthSession(s)
        } catch {
            // Tokens stale—clear and remain signed out.
            KeychainStore.clearSession()
            applyAuthSession(nil)
        }
    }

    // --- Apple sign-in helpers ---
    static func performAppleSignIn(request: ASAuthorizationAppleIDRequest, on window: UIWindow?) async throws -> ASAuthorizationAppleIDCredential {
        try await withCheckedThrowingContinuation { cont in
            let controller = ASAuthorizationController(authorizationRequests: [request])
            let coordinator = AppleCoordinator { result in cont.resume(with: result) }
            controller.delegate = coordinator
            controller.presentationContextProvider = coordinator
            coordinator.window = window
            controller.performRequests()
        }
    }

    final class AppleCoordinator: NSObject, ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
        var window: UIWindow?
        private let completion: (Result<ASAuthorizationAppleIDCredential, Error>) -> Void
        init(completion: @escaping (Result<ASAuthorizationAppleIDCredential, Error>) -> Void) { self.completion = completion }
        func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
            window ?? UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first?.keyWindow ?? UIWindow()
        }
        func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
            if let cred = authorization.credential as? ASAuthorizationAppleIDCredential { completion(.success(cred)) }
            else { completion(.failure(SimpleError(message: "Invalid Apple credential"))) }
        }
        func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
            completion(.failure(error))
        }
    }

    static func randomNonceString(length: Int = 32) -> String {
        let charset: [Character] = Array("0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._")
        var result = "", remaining = length
        while remaining > 0 {
            var bytes = [UInt8](repeating: 0, count: 16)
            let status = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
            if status != errSecSuccess { fatalError("Unable to generate nonce.") }
            bytes.forEach { b in if remaining > 0, b < charset.count { result.append(charset[Int(b)]); remaining -= 1 } }
        }
        return result
    }

    static func sha256(_ input: String) -> String {
        let data = Data(input.utf8)
        return SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    static func isAnonymousUser(_ user: User) -> Bool {
        let provider = user.appMetadata["provider"]?.description.lowercased() ?? ""
        return provider == "anonymous" || provider == "anon"
    }
}

// MARK: - Keychain minimal session storage

private enum KeychainStore {
    private static let service = "com.zainlatif.Swoopy.supabase"
    private static let accountAccess = "accessToken"
    private static let accountRefresh = "refreshToken"

    struct Credentials { let accessToken: String; let refreshToken: String }

    static func saveSession(accessToken: String, refreshToken: String) {
        save(key: accountAccess, value: accessToken)
        save(key: accountRefresh, value: refreshToken)
    }
    static func loadSession() -> Credentials? {
        guard let access = load(key: accountAccess), let refresh = load(key: accountRefresh) else { return nil }
        return .init(accessToken: access, refreshToken: refresh)
    }
    static func clearSession() { delete(key: accountAccess); delete(key: accountRefresh) }

    private static func save(key: String, value: String) {
        let data = Data(value.utf8)
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecValueData as String: data
        ]
        SecItemDelete(q as CFDictionary)
        SecItemAdd(q as CFDictionary, nil)
    }
    private static func load(key: String) -> String? {
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    private static func delete(key: String) {
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(q as CFDictionary)
    }
}

// MARK: - Time helper

private enum ISOTime {
    private static let f: ISO8601DateFormatter = {
        let x = ISO8601DateFormatter()
        x.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return x
    }()
    static func isoString(_ d: Date) -> String { f.string(from: d) }
}

// MARK: - Errors

struct SimpleError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}
