import SwiftUI

enum AppColor {
  static let darkGreen = Color(hex: "#00513F")
  static let cta       = Color(hex: "#B4DD4E")
  static let muted     = Color(hex: "#656565")
  static let text      = Color.black
  static let textInv   = Color.white
  static let stroke    = darkGreen
  static let surface   = Color.white
  static let bg        = Color(.systemGroupedBackground)
}

extension Color {
  init(hex: String) {
    var s = hex.trimmingCharacters(in: .whitespacesAndNewlines)
    s = s.replacingOccurrences(of: "#", with: "")
    var rgb: UInt64 = 0; Scanner(string: s).scanHexInt64(&rgb)
    let r = Double((rgb >> 16) & 0xFF) / 255.0
    let g = Double((rgb >> 8) & 0xFF) / 255.0
    let b = Double(rgb & 0xFF) / 255.0
    self = Color(red: r, green: g, blue: b)
  }
}
